package src;
import java.util.Date;

public class BorrowTransaction extends Transaction {

    public BorrowTransaction(int transactionId, Date date, Book book, Member member) {
        super(transactionId, date, book, member);
    }

    @Override
    public void execute() {
        if (book.isAvailable()) {
            book.borrow();
            member.borrowBook(book.getBookId());
            System.out.println("Borrow transaction executed successfully.");
        } else {
            System.out.println("Book is not available for borrowing.");
        }
    }
}
