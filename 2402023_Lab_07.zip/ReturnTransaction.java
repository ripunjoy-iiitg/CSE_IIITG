package src;
import java.util.Date;

public class ReturnTransaction extends Transaction {

    public ReturnTransaction(int transactionId, Date date, Book book, Member member) {
        super(transactionId, date, book, member);
    }

    @Override
    public void execute() {
        book.returnBook();
        member.returnBook(book.getBookId());
        System.out.println("Return transaction executed successfully.");
    }
}
