package src;
import java.util.ArrayList;
import java.util.List;

public class Member {
    private int memberId;
    private String name;
    private List<Integer> borrowedBooks;

    public Member(int memberId, String name) {
        this.memberId = memberId;
        this.name = name;
        this.borrowedBooks = new ArrayList<>();
    }

    public int getMemberId() {
        return memberId;
    }

    public String getName() {
        return name;
    }

    public List<Integer> getBorrowedBooks() {
        return borrowedBooks;
    }

    public void borrowBook(int bookId) {
        borrowedBooks.add(bookId);
        System.out.println("Book with ID " + bookId + " borrowed by member " + name);
    }

    public void returnBook(int bookId) {
        if (borrowedBooks.remove(Integer.valueOf(bookId))) {
            System.out.println("Book with ID " + bookId + " returned by member " + name);
        } else {
            System.out.println("Book with ID " + bookId + " is not found in borrowed list.");
        }
    }
}
