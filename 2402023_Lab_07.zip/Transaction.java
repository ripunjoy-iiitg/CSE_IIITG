package src;
import java.util.Date;

public abstract class Transaction {
    protected int transactionId;
    protected Date date;
    protected Book book;
    protected Member member;

    public Transaction(int transactionId, Date date, Book book, Member member) {
        this.transactionId = transactionId;
        this.date = date;
        this.book = book;
        this.member = member;
    }

    public abstract void execute();
}
