package src;
import java.util.ArrayList;
import java.util.List;

public class Librarian {
    private int librarianId;
    private String name;
    private List<Book> books;

    public Librarian(int librarianId, String name) {
        this.librarianId = librarianId;
        this.name = name;
        this.books = new ArrayList<>();
    }

    public void addBook(Book book) {
        books.add(book);
        System.out.println("Book titled \"" + book.getTitle() + "\" added to the library.");
    }

    public void removeBook(int bookId) {
        books.removeIf(book -> book.getBookId() == bookId);
        System.out.println("Book with ID " + bookId + " removed from the library.");
    }

    public Book searchBook(int bookId) {
        for (Book book : books) {
            if (book.getBookId() == bookId) {
                return book;
            }
        }
        System.out.println("Book with ID " + bookId + " not found.");
        return null;
    }
}
