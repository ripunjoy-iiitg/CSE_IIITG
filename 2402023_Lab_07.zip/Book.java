package src;
public class Book {
    private int bookId;
    private String title;
    private String author;
    private boolean availability;

    public Book(int bookId, String title, String author) {
        this.bookId = bookId;
        this.title = title;
        this.author = author;
        this.availability = true; 
    }

    public int getBookId() {
        return bookId;
    }

    public String getTitle() {
        return title;
    }

    public String getAuthor() {
        return author;
    }

    public boolean isAvailable() {
        return availability;
    }

    private void setAvailability(boolean availability) {
        this.availability = availability;
    }

    public void borrow() {
        if (availability) {
            setAvailability(false);
            System.out.println("Book borrowed successfully.");
        } else {
            System.out.println("Book is not available.");
        }
    }

    public void returnBook() {
        setAvailability(true);
        System.out.println("Book returned successfully.");
    }

    public void displayDetails() {
        System.out.println("Book ID: " + bookId + ", Title: " + title + ", Author: " + author + ", Available: " + availability);
    }
}
