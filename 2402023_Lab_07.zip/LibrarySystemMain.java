package src;
import java.util.Date;

public class LibrarySystemMain {
    public static void main(String[] args) {
        Librarian librarian = new Librarian(1, "Rip");

        Book book1 = new Book(101, "Harry Potter", "JK Rowling");
        Book book2 = new Book(102, "Percy Jackson", "Rick Riorden");

        librarian.addBook(book1);
        librarian.addBook(book2);

        Member member = new Member(1, "Hari");

        Transaction borrowTransaction = new BorrowTransaction(1001, new Date(), book1, member);
        borrowTransaction.execute();

        Transaction returnTransaction = new ReturnTransaction(1002, new Date(), book1, member);
        returnTransaction.execute();
        
        book1.displayDetails();
        book2.displayDetails();
    }
}

